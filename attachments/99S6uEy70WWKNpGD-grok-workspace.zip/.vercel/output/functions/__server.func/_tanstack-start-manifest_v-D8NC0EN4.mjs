//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D8NC0EN4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/carteira",
			"/documento"
		],
		preloads: ["/assets/index-AcgS3DSJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-AcgS3DSJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-MmOjcbrs.js",
			"/assets/chevron-right-DXKNxLGs.js",
			"/assets/BottomNav-DDKKbR2y.js"
		]
	},
	"/carteira": {
		filePath: "/workspace/src/routes/carteira.tsx",
		children: void 0,
		preloads: [
			"/assets/carteira-DkjElpRZ.js",
			"/assets/chevron-left-C9OUEy_z.js",
			"/assets/BottomNav-DDKKbR2y.js"
		]
	},
	"/documento": {
		filePath: "/workspace/src/routes/documento.tsx",
		children: void 0,
		preloads: [
			"/assets/documento-TNXLkUm7.js",
			"/assets/chevron-left-C9OUEy_z.js",
			"/assets/chevron-right-DXKNxLGs.js",
			"/assets/BottomNav-DDKKbR2y.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
